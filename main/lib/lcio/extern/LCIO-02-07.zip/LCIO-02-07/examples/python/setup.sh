#!/bin/bash
export PYTHONPATH=${PWD}:$PYTHONPATH
