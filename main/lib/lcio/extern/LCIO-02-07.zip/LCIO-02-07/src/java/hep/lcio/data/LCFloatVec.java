
package hep.lcio.data;


/** Please use hep.lcio.event.LCFloatVec !
 * 
 * @deprecated
 * @author gaede 
 * @version Mar 12, 2003
 * @see LCObject
  */
public interface LCFloatVec extends hep.lcio.event.LCFloatVec {

}

