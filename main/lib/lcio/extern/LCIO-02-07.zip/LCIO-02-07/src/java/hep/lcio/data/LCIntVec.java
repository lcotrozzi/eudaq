
package hep.lcio.data;


/** Please use hep.lcio.event.LCIntVec !
 * 
 * @deprecated
 * @author gaede 
 * @version Mar 12, 2003
 * @see LCObject
  */
public interface LCIntVec extends hep.lcio.event.LCIntVec {

}

