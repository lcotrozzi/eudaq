//
// LCObjectHandle.h has moved to UTIL
//
#include "UTIL/LCObjectHandle.h"
