//
//  file has moved to EVENT - please use new path
//
#include "EVENT/LCFloatVec.h"

